bior_annotate -s status6.out < example.vcf > out6.tsv
