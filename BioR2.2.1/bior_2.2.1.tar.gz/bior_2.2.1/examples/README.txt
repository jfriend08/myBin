This directory contains a collection of pre-canned examples that you can use to validate that BioR is functioning and that everything is set up correctly on your machine.

To run the examples, make sure to go up one directory and source the setup.env file!
$cd ..
$ source setupEnv.sh 
$ cd -
/Users/m102417/workspace/bior_pipeline/examples
$


