This directory contains all license information from the dependent projects that BioR uses.
A complete listing of these projects and the licenses used are in deps.txt

Based on the feedback received we have changed our license for BioR to 
GNU General Public License Version 3
  http://www.gnu.org/licenses/gpl.html
  http://www.gnu.org/licenses/quick-guide-gplv3.html 
This will enable any user to use the software both for academic research
use as well as "fee for service" model in Core Laboratories.

See GPL.txt for more info.